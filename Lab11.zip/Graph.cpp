//Author: Monynich Kiem
//Section: 03


#include <iostream>
#include <map>
#include <set>
#include "Graph.h"
#include <queue>

using namespace std;

//there is a private member named map<char, set<char> > adjMap;

Graph::Graph()
{
	//default constructor
}//end Graph default constructor

bool Graph::hasEdge(char v, char w)
{
	//check if edge exists between v and w
	bool edge_exists = false;
	if (adjMap[v].find(w) != adjMap[v].end())
	{
		edge_exists = true;
	}
	return edge_exists;

}//end hasEdge

void Graph::addEdge(char v, char w)
{
	//to add an edge between v and w to the graph
	if (!hasEdge(v,w))
	{
		adjMap[v].insert(w);
	}
	if (!hasEdge(w,v))
	{
		adjMap[w].insert(v);
	}

}//end addEdge

int Graph::BFS(char s, char t, map<char, int>& distance, map<char, char>& go_through)
{

for (auto v = adjMap.begin(); v != adjMap.end(); v++)
	{
		distance[v->first] = -1;
	}

	queue<char> Q;
	distance[s] = 0;
	go_through[s] = s;

	Q.push(s);
	char current = s;

	while (!Q.empty() && current != t)
		{
		current = Q.front(); 
		
		  for (auto w = adjMap[current].begin(); w != adjMap[current].end(); w++)
		  
			  if (distance[*w] == -1)
			  {
				  distance[*w] = distance[current]+1;

				  go_through[*w] = current;

				  Q.push(*w);
			  }

		  Q.pop();
		}
	return distance[t];	
}
