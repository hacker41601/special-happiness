/* 
 * File: smartReverse.cpp
 * Purpose: provide the implementation of the smartReverse class
 *
 * Author: Monynich Kiem
 *
 */

#include <stack>
#include "smartReverse.h"

// default constructor
smartReverse::smartReverse()
{
	
}

// constructor: initialize str with ini_str passing as a parameter
smartReverse::smartReverse(string ini_str)
{
	str = ini_str;
}

// return the current value of the private data member: str
string smartReverse::getString() const
{
	return str;
}

// set the value of str to be the passed in parameter input_str
void smartReverse::setString(string input_str)
{
	str = input_str;
}

// return a reversed string from str
// using a loop to implement
// Note that str has not been changed
string smartReverse::rev() const
{
	string rev_str;
	for (int i = str.length()-1; i >= 0; i--)
    {
        rev_str = rev_str + str[i]; // you can also use str.at(i)
    }
    return rev_str;
}

// return a reversed string from str
// using recursion to implement
// Note that str has not been changed
string smartReverse::rev_recursive() const
{
	string revstr = "";
	smartReverse anotherString;
	anotherString.setString(str);
	int endString = anotherString.getString().length()-1;
	if (anotherString.getString().length() == 1 || anotherString.getString().length() ==0) //base case 
	{
		revstr = revstr + anotherString.getString();
		return revstr;
	}
	else {
	//recursive case
		revstr = anotherString.getString().at(endString);
		anotherString.setString(anotherString.getString().substr(0, endString));
		revstr = revstr + anotherString.rev_recursive();
		return revstr;
	}
}

// return a reversed string from str
// using a stack to implement
// Note that str has not been changed
string smartReverse::rev_stack() const
{
	int i;
	stack <int> yourstack;
	string revstr = "";
	for (char c:str)
		yourstack.push(c);
	for (char c:str) {
		revstr += yourstack.top();
		yourstack.pop();
	}
	return revstr;
}
